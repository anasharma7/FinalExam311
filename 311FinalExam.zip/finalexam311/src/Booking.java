import java.time.LocalDate;
public class Booking {
    private Flight flight;

    public Booking(Flight flight) {
        this.flight = flight;
    }

    public Flight getFlight() {
        return flight;
    }

    public double getCost() {
        double totalCost = 0.0;
        for (Flight flight : flights) {
            totalCost += flight.getBasePrice() + flight.getDistance() * 0.1;
        }
        return totalCost;
    }
}

