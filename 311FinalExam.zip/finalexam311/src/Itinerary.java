public class Itinerary {
    private Flight flight;

    public Itinerary(Flight flight) {
        this.flight = flight;
    }

    public Flight getFlight() {
        return flight;
    }

    public double getTotalCost() {
        double totalCost = flight.getCost();
        return totalCost;
    }
}
